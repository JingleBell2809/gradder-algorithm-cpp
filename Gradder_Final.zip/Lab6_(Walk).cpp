#include <iostream>
using namespace std;

int arr[100][100];

int Walk(int m,int n){
	if(m==0 || n==0){
//		cout<<m<<" "<<n<<" "<<arr[m][n]<<" m=0 n=0"<<endl;
//		for(int i=0;i<=2;i++){
//			for(int j=0;j<=5;j++){
//				cout<<arr[i][j]<<" ";
//			}
//			cout<<endl;
//		}
		return 0;
	}
	if(m==1 && n==1){
//		cout<<m<<" "<<n<<" "<<arr[m][n]<<" m=1 n=1"<<endl;
//		for(int i=0;i<=2;i++){
//			for(int j=0;j<=5;j++){
//				cout<<arr[i][j]<<" ";
//			}
//			cout<<endl;
//		}
		return 1;
	}else{
		if(arr[m][n] == 0){
//			cout<<endl<<"arr[m][n]==0  - - - - - - - - BF >> walk | m="<<m<<" n="<<n<<endl;
//			for(int i=0;i<=2;i++){
//			for(int j=0;j<=5;j++){
//				cout<<arr[i][j]<<" ";
//			}
//			cout<<endl;
//			}
			arr[m][n] = Walk(m-1,n) + Walk(m,n-1);
//			cout<<endl<<"arr[m][n]==0  - - - - - - - - AT >> walk | m="<<m<<" n="<<n<<endl;
//			for(int i=0;i<=2;i++){
//			for(int j=0;j<=5;j++){
//				cout<<arr[i][j]<<" ";
//			}
//			cout<<endl;
//		}
			return arr[m][n];
		}else{
//			cout<<m<<" "<<n<<" "<<arr[m][n]<<endl;
//			for(int i=0;i<=2;i++){
//			for(int j=0;j<=5;j++){
//				cout<<arr[i][j]<<" ";
//			}
//			cout<<endl;
//		}
			return arr[m][n];
		}
	}
}

int main(){
	int m,n;
	cin >>m>>n;
	
	cout<<Walk(m,n);
//	cout<<max;
}
