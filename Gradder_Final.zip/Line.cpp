#include<iostream>
using namespace std;

int main()
{
    cout<<"3";
};
